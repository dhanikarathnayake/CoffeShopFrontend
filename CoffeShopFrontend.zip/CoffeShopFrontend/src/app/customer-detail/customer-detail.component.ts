import { Component, OnInit,ViewChild } from '@angular/core';
import {CustomerDetail} from  '../Models/MasterModels/CustomerDetailModel';
import {CustomerDetailService} from '../Services/MasterService/CustomerDetail.service';
import {ViewCustomerDetail} from '../Models/MasterModels/CustomerDetailModel';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-customer-detail',
  templateUrl: './customer-detail.component.html',
  styleUrls: ['./customer-detail.component.scss']
})
export class CustomerDetailComponent implements OnInit {

  @ViewChild(MatPaginator, {static: false}) PaginatorCus
  CustomerDetail=new CustomerDetail();
  ViewCustomerDetailObject :ViewCustomerDetail= new ViewCustomerDetail();
  ViewCustomerDetailList : ViewCustomerDetail[];

  constructor(private CustomerDetailService: CustomerDetailService) { }

  displayedColumns: string[] = ['customerDetailID','customerName','custID','telephoneNo','address'];
  dataSource = new MatTableDataSource();

  

  ngOnInit() {
    this.getCutomerDetails();
  }

  onSubmit()
  {
   this.CustomerDetailService.InsertCustomerDetail(this.CustomerDetail)
   .subscribe(
    data=> {console.log('Success!',data);
    this.ngOnInit();
  }
    ) 
  }

  getCutomerDetails(): void{
 
    this.CustomerDetailService.GetCutomerDetails()
    .subscribe(response => {
        this.ViewCustomerDetailList = response.data
        this.dataSource = new MatTableDataSource(this.ViewCustomerDetailList);
        this.dataSource.paginator = this.PaginatorCus;
        
    });
  }

}
