export class CustomerDetail {
  
    firstname :string;
    lastname :string;
    custid: string;
    telephone: string;
    address: string;
    address2: string;

  }
export class ViewCustomerDetail
{
  customerDetailID : number;
  customerName : string;
  custID :string;
  telephoneNo :string;
  address :string;
}
  