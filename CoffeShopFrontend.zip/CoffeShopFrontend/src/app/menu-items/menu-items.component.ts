import { Component, OnInit,ViewChild } from '@angular/core';
import {MenuItemService} from '../Services/MasterService/MenuItem.service';
import {MenuItem} from '../Models/MasterModels/MenuItemModel';
import { MatTableDataSource } from '@angular/material/table';
import {Menu} from '../Models/MasterModels/MenuItemModel';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-menu-items',
  templateUrl: './menu-items.component.html',
  styleUrls: ['./menu-items.component.scss']
})
export class MenuItemsComponent implements OnInit {

  @ViewChild(MatPaginator, {static: false}) PaginatorMenu
  MenuItemObject :MenuItem= new MenuItem();
  MenuItemList : MenuItem[];
  Menu = new Menu();

  constructor( private MenuItemService: MenuItemService) { }

  displayedColumns: string[] = ['MenuID','MenuName','MenuPrice'];
  dataSource = new MatTableDataSource();

  ngOnInit() {
    this.getMenuItems();
  }

  getMenuItems(): void{
 
    this.MenuItemService.getMenus()
    .subscribe(response => {
        this.MenuItemList = response.data
        this.dataSource = new MatTableDataSource(this.MenuItemList);
        this.dataSource.paginator = this.PaginatorMenu;
    });
  }

  onSubmit()
  {
   this.MenuItemService.InsertMenuDetails(this.Menu)
   .subscribe(
     data=> {console.log('Success!',data);
     this.ngOnInit();
   }
     ) 
  }


}
