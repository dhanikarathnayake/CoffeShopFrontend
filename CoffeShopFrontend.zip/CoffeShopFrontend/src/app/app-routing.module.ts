import { NgModule } from '@angular/core';
import { BrowserModule  } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { CommonLayoutComponent } from './common-layout/common-layout.component';


const routes: Routes =[
  // {
  //   path: '',
  //   redirectTo: 'Login',
  //   pathMatch: 'full',
  // },
  {
    path: '',
    component: CommonLayoutComponent,
    children: [{
      path: '',
      loadChildren: () => import('./common-layout/common-layout.module').then(m => m.CommonLayoutModule)
    }]
  },
  // {
  //   path: 'Login',
  //   component: LoginComponent
  // },

];

@NgModule({
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes,{
       useHash: true
    })
  ],
  exports: [
  ],
})
export class AppRoutingModule { }

