export class Order {
  
    menuID : number;
    customerDetailID :number;
    paymentMethodID :number;
}

export class PaymentMethodDetails
{
    paymentMethodID : number;
    paymentMethodDescription : string;
}


export class ViewOrderDetails
{
    menuName : string;
    itemPrice : string;
    customerName :string;
    paymentOn :string;
    paymentMethod :string;
    paymentStatus :string;

}
