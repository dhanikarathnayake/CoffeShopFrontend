
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { Users } from '../Models/MasterModels/UserModel';
import { Component, OnInit, ViewChild,ElementRef } from '@angular/core';
import { FormGroupDirective, FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';



@Component({
  selector: 'app-common-layout',
  templateUrl: './common-layout.component.html',
  styleUrls: ['./common-layout.component.scss']
})

export class CommonLayoutComponent implements OnInit {

  @ViewChild(FormGroupDirective, { static: false }) TestFormDirective: FormGroupDirective;

  TestForm: FormGroup;

  constructor(
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {

    this.TestForm = this.fb.group({
      list: new FormControl('')

    });

  }

  List: string[] = ['First Name','Last Name','Mobile Number', 'Address', 'Actions'];
  // List: Users = new  Users();

  // this.List = ['Kamal','Nimal','Sunil']

}
