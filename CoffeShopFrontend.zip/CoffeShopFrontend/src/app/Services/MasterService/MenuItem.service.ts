
import { CommonHTTPRequestsService } from "./../CommonHTTPRequests.service";
import { GlobalParametersService } from "./../GlobalParameters.service";
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Menu } from "../../Models/MasterModels/MenuItemModel";

@Injectable({
  providedIn: 'root'
})
export class MenuItemService {

  Menu: Menu[];

  constructor(
    private HTTPRequests: CommonHTTPRequestsService,
    private GlobalParameters: GlobalParametersService) {
  }

  getMenus(): Observable<any> {
    //alert(menuId)
    return this.HTTPRequests.RequestGET(`${this.GlobalParameters.primaryAPI}/api/CoffeeShop/Menu/SelectMenu`)
}

    InsertMenuDetails(Menu: Menu): Observable<any> {
    return this.HTTPRequests.RequestPOST(Menu, `${this.GlobalParameters.primaryAPI}/api/CoffeeShop/Menu/InsertMenuDetails`)
 }

}
