
import { CommonHTTPRequestsService } from "./../CommonHTTPRequests.service";
import { GlobalParametersService } from "./../GlobalParameters.service";
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {Order} from "../../Models/MasterModels/OrderModel";

@Injectable({
  providedIn: 'root'
})
export class OrderService {

    Order: Order[];

  constructor(
    private HTTPRequests: CommonHTTPRequestsService,
    private GlobalParameters: GlobalParametersService) {
  }

  GetPaymentMethodDetails(): Observable<any> {
    return this.HTTPRequests.RequestGET(`${this.GlobalParameters.primaryAPI}/api/CoffeeShop/Payment/SelectPaymentMethod`)
   }

   InsertOrderDetail(Order: Order): Observable<any> {
    return this.HTTPRequests.RequestPOST(Order, `${this.GlobalParameters.primaryAPI}/api/CoffeeShop/Order/InsertOrder`)
   }

   GetOrderDetails(): Observable<any> {
    return this.HTTPRequests.RequestGET(`${this.GlobalParameters.primaryAPI}/api/CoffeeShop/Payment/SelectPaymentDetails`)
   }


}
