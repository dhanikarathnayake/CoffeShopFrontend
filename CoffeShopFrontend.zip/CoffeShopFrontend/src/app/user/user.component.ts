import { Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from '../Services/MasterService/User.service'
import { Users } from '../Models/MasterModels/UserModel'
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  
  UsersObject: Users = new Users();
  usersList: Users[];

  
   
  constructor(
  private UserService: UserService
    ) {
      //this.dataSource = new MatTableDataSource(this.usersList);
    }


    displayedColumns: string[] = ['Category','CategoryID','CoffeeMenuID', 'Name', 'Price'];
    dataSource = new MatTableDataSource();
    


  ngOnInit(): void {
    this.getMenuItems();
   }


  getMenuItems(): void{
    //alert('Menu')
    this.UserService.getMenu(-999,-999)
    .subscribe(response => {
        console.log('response',response);
        this.usersList = response.Data
        this.dataSource = new MatTableDataSource(this.usersList);
    });
  }


}
