
import { CommonHTTPRequestsService } from "./../CommonHTTPRequests.service";
import { GlobalParametersService } from "./../GlobalParameters.service";
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {CustomerDetail} from '../../Models/MasterModels/CustomerDetailModel';

@Injectable({
  providedIn: 'root'
})
export class CustomerDetailService {

    CustomerDetail: CustomerDetail[];

  constructor(
    private HTTPRequests: CommonHTTPRequestsService,
    private GlobalParameters: GlobalParametersService) {
  }

   InsertCustomerDetail(CustomerDetail: CustomerDetail): Observable<any> {
    return this.HTTPRequests.RequestPOST(CustomerDetail, `${this.GlobalParameters.primaryAPI}/api/CoffeeShop/Customer/InsertCustomerDetails`)
   }

   
    GetCutomerDetails(): Observable<any> {
     return this.HTTPRequests.RequestGET(`${this.GlobalParameters.primaryAPI}/api/CoffeeShop/Customer/SelectCustomerDetails`)
    }

  // InsertUsers(users: Users): Observable<any> {
  //   return this.HTTPRequests.RequestPOST(users, `${this.GlobalParameters.primaryAPI}end_point_here`)
  // }

  // DeleteUsers(users: Users): Observable<any> {
  //   return this.HTTPRequests.RequestPOST(users, `${this.GlobalParameters.primaryAPI}end_point_here`)
  // }

//   getMenus(): Observable<any> {
//     //alert(menuId)
//     return this.HTTPRequests.RequestGET(`${this.GlobalParameters.primaryAPI}/api/CoffeeShop/Menu/SelectMenu`)
//}

}
