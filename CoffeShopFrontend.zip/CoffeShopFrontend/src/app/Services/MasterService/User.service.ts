
import { CommonHTTPRequestsService } from "./../CommonHTTPRequests.service";
import { GlobalParametersService } from "./../GlobalParameters.service";
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Users } from "../../Models/MasterModels/UserModel";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  users: Users[];

  constructor(
    private HTTPRequests: CommonHTTPRequestsService,
    private GlobalParameters: GlobalParametersService) {
  }

  // InsertUsers(users: Users): Observable<any> {
  //   return this.HTTPRequests.RequestPOST(users, `${this.GlobalParameters.primaryAPI}end_point_here`)
  // }

  // InsertUsers(users: Users): Observable<any> {
  //   return this.HTTPRequests.RequestPOST(users, `${this.GlobalParameters.primaryAPI}end_point_here`)
  // }

  // DeleteUsers(users: Users): Observable<any> {
  //   return this.HTTPRequests.RequestPOST(users, `${this.GlobalParameters.primaryAPI}end_point_here`)
  // }

  getMenu(menuId: number ,categoryId: number): Observable<any> {
    //alert(menuId)
    return this.HTTPRequests.RequestGET(`${this.GlobalParameters.primaryAPI}/api/MenuDetails/Select/${menuId}/${categoryId}`)
}

}
