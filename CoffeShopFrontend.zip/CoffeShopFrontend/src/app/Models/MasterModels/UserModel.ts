export class Users {
  
  Category :string;
  CategoryID: number;
  CoffeeMenuID: number
  Name: string;
  Price: number;

}
