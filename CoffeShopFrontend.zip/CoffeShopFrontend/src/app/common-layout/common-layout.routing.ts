import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserComponent } from '../user/user.component';
import {MenuItemsComponent} from '../menu-items/menu-items.component';
import {CustomerDetailComponent} from '../customer-detail/customer-detail.component';
import {OrderComponent} from '../order/order.component';


export const CommonLayoutRoutes: Routes = [
  {
    path: 'User',
    component: UserComponent
  },
  {
    path: 'MenuItems',
    component: MenuItemsComponent
  },
  {
    path: 'CustomerDetail',
    component: CustomerDetailComponent
  },
  {
    path: 'Order',
    component: OrderComponent
  }


];

