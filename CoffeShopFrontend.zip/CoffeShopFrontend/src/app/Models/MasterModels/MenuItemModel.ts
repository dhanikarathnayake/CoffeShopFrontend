export class MenuItem {
  
    MenuID :number;
    MenuName: string;
    MenuPrice: string;
  
  }

export class Menu 
{
    menuName :string;
    menuPrice :string;
}
  