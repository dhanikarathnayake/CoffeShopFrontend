import { Component, OnInit ,ViewChild} from '@angular/core';
import {MenuItem} from '../Models/MasterModels/MenuItemModel';
import {ViewCustomerDetail} from '../Models/MasterModels/CustomerDetailModel';
import {OrderService} from '../Services/MasterService/Order.service';
import {MenuItemService} from '../Services/MasterService/MenuItem.service';
import {CustomerDetailService} from '../Services/MasterService/CustomerDetail.service';
import {PaymentMethodDetails} from '../Models/MasterModels/OrderModel';
import {Order} from '../Models/MasterModels/OrderModel';
import {ViewOrderDetails} from '../Models/MasterModels/OrderModel';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss']
})
export class OrderComponent implements OnInit {

  @ViewChild(MatPaginator, {static: false}) PaginatorOrder
  ViewMenuDetailsList: MenuItem[];
  ViewCustomerDetailsList :ViewCustomerDetail [];
  ViewPaymentMethodDetailsList :PaymentMethodDetails[];
  Order = new Order();
  ViewOrderDetailsObject :ViewOrderDetails= new ViewOrderDetails();
  ViewOrderDetailsList : ViewOrderDetails[];

  constructor(
    private OrderService:OrderService,
    private MenuItemService:MenuItemService,
    private CustomerDetailService :CustomerDetailService
    )
     { }

     displayedColumns: string[] = ['menuName','itemPrice','customerName','paymentOn','paymentMethod','paymentStatus'];
     dataSource = new MatTableDataSource();

  ngOnInit() {
    this.getMenus();
    this.GetCutomerDetails();
    this.GetPaymentMethodDetails();
    this.GetOrderDetails();

  }

  getMenus(): void{
    this.MenuItemService.getMenus()
    .subscribe(response => {
        this.ViewMenuDetailsList = response.data
        
    });


    }

    GetCutomerDetails(): void{
 
      this.CustomerDetailService.GetCutomerDetails()
      .subscribe(response => {
          this.ViewCustomerDetailsList = response.data
          
      });
  
      }

      GetPaymentMethodDetails(): void{
 
        this.OrderService.GetPaymentMethodDetails()
        .subscribe(response => {
            this.ViewPaymentMethodDetailsList = response.data
            
        });
    
        }

        onSubmit()
        {
         this.OrderService.InsertOrderDetail(this.Order)
          .subscribe(
          data=> {console.log('Success!',data);
          this.ngOnInit();
   }
     ) 
        }

        GetOrderDetails(): void{
 
          this.OrderService.GetOrderDetails()
          .subscribe(response => {
            this.ViewOrderDetailsList = response.data
            this.dataSource = new MatTableDataSource(this.ViewOrderDetailsList);
            this.dataSource.paginator = this.PaginatorOrder;
              
          });
      
          }

}
